﻿namespace TriangleDialog
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.buttonCalc = new System.Windows.Forms.Button();
            this.labelA = new System.Windows.Forms.Label();
            this.labelB = new System.Windows.Forms.Label();
            this.textBoxA = new System.Windows.Forms.TextBox();
            this.textBoxB = new System.Windows.Forms.TextBox();
            this.pictureBoxTri = new System.Windows.Forms.PictureBox();
            this.labelArea = new System.Windows.Forms.Label();
            this.labelHypo = new System.Windows.Forms.Label();
            this.labelPeri = new System.Windows.Forms.Label();
            this.textBoxAccu = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkArea = new System.Windows.Forms.CheckBox();
            this.chkHypotenuse = new System.Windows.Forms.CheckBox();
            this.chkPerimeter = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTri)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonCalc
            // 
            this.buttonCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCalc.Location = new System.Drawing.Point(12, 369);
            this.buttonCalc.Name = "buttonCalc";
            this.buttonCalc.Size = new System.Drawing.Size(150, 61);
            this.buttonCalc.TabIndex = 0;
            this.buttonCalc.Text = "Calculate";
            this.buttonCalc.UseVisualStyleBackColor = true;
            this.buttonCalc.Click += new System.EventHandler(this.buttonCalc_Click);
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelA.Location = new System.Drawing.Point(12, 181);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(53, 17);
            this.labelA.TabIndex = 1;
            this.labelA.Text = "Side A:";
            // 
            // labelB
            // 
            this.labelB.AutoSize = true;
            this.labelB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelB.Location = new System.Drawing.Point(12, 208);
            this.labelB.Name = "labelB";
            this.labelB.Size = new System.Drawing.Size(53, 17);
            this.labelB.TabIndex = 2;
            this.labelB.Text = "Side B:";
            // 
            // textBoxA
            // 
            this.textBoxA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxA.Location = new System.Drawing.Point(87, 178);
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.Size = new System.Drawing.Size(75, 23);
            this.textBoxA.TabIndex = 3;
            this.textBoxA.Text = "10";
            // 
            // textBoxB
            // 
            this.textBoxB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxB.Location = new System.Drawing.Point(87, 209);
            this.textBoxB.Name = "textBoxB";
            this.textBoxB.Size = new System.Drawing.Size(75, 23);
            this.textBoxB.TabIndex = 4;
            this.textBoxB.Text = "5";
            // 
            // pictureBoxTri
            // 
            this.pictureBoxTri.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxTri.Image")));
            this.pictureBoxTri.Location = new System.Drawing.Point(12, 12);
            this.pictureBoxTri.Name = "pictureBoxTri";
            this.pictureBoxTri.Size = new System.Drawing.Size(150, 150);
            this.pictureBoxTri.TabIndex = 5;
            this.pictureBoxTri.TabStop = false;
            // 
            // labelArea
            // 
            this.labelArea.AutoSize = true;
            this.labelArea.Location = new System.Drawing.Point(12, 447);
            this.labelArea.Name = "labelArea";
            this.labelArea.Size = new System.Drawing.Size(13, 13);
            this.labelArea.TabIndex = 6;
            this.labelArea.Text = "0";
            // 
            // labelHypo
            // 
            this.labelHypo.AutoSize = true;
            this.labelHypo.Location = new System.Drawing.Point(12, 476);
            this.labelHypo.Name = "labelHypo";
            this.labelHypo.Size = new System.Drawing.Size(13, 13);
            this.labelHypo.TabIndex = 7;
            this.labelHypo.Text = "0";
            // 
            // labelPeri
            // 
            this.labelPeri.AutoSize = true;
            this.labelPeri.Location = new System.Drawing.Point(12, 509);
            this.labelPeri.Name = "labelPeri";
            this.labelPeri.Size = new System.Drawing.Size(13, 13);
            this.labelPeri.TabIndex = 8;
            this.labelPeri.Text = "0";
            // 
            // textBoxAccu
            // 
            this.textBoxAccu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAccu.Location = new System.Drawing.Point(87, 238);
            this.textBoxAccu.Name = "textBoxAccu";
            this.textBoxAccu.Size = new System.Drawing.Size(75, 23);
            this.textBoxAccu.TabIndex = 10;
            this.textBoxAccu.Text = "2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Accuracy:";
            // 
            // chkArea
            // 
            this.chkArea.AutoSize = true;
            this.chkArea.Checked = true;
            this.chkArea.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkArea.Location = new System.Drawing.Point(16, 280);
            this.chkArea.Name = "chkArea";
            this.chkArea.Size = new System.Drawing.Size(48, 17);
            this.chkArea.TabIndex = 11;
            this.chkArea.Text = "Area";
            this.chkArea.UseVisualStyleBackColor = true;
            // 
            // chkHypotenuse
            // 
            this.chkHypotenuse.AutoSize = true;
            this.chkHypotenuse.Checked = true;
            this.chkHypotenuse.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkHypotenuse.Location = new System.Drawing.Point(16, 303);
            this.chkHypotenuse.Name = "chkHypotenuse";
            this.chkHypotenuse.Size = new System.Drawing.Size(83, 17);
            this.chkHypotenuse.TabIndex = 12;
            this.chkHypotenuse.Text = "Hypotenuse";
            this.chkHypotenuse.UseVisualStyleBackColor = true;
            // 
            // chkPerimeter
            // 
            this.chkPerimeter.AutoSize = true;
            this.chkPerimeter.Checked = true;
            this.chkPerimeter.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkPerimeter.Location = new System.Drawing.Point(16, 326);
            this.chkPerimeter.Name = "chkPerimeter";
            this.chkPerimeter.Size = new System.Drawing.Size(70, 17);
            this.chkPerimeter.TabIndex = 13;
            this.chkPerimeter.Text = "Perimeter";
            this.chkPerimeter.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(181, 530);
            this.Controls.Add(this.chkPerimeter);
            this.Controls.Add(this.chkHypotenuse);
            this.Controls.Add(this.chkArea);
            this.Controls.Add(this.textBoxAccu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelPeri);
            this.Controls.Add(this.labelHypo);
            this.Controls.Add(this.labelArea);
            this.Controls.Add(this.pictureBoxTri);
            this.Controls.Add(this.textBoxB);
            this.Controls.Add(this.textBoxA);
            this.Controls.Add(this.labelB);
            this.Controls.Add(this.labelA);
            this.Controls.Add(this.buttonCalc);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Triangle";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxTri)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonCalc;
        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.Label labelB;
        private System.Windows.Forms.TextBox textBoxA;
        private System.Windows.Forms.TextBox textBoxB;
        private System.Windows.Forms.PictureBox pictureBoxTri;
        private System.Windows.Forms.Label labelArea;
        private System.Windows.Forms.Label labelHypo;
        private System.Windows.Forms.Label labelPeri;
        private System.Windows.Forms.TextBox textBoxAccu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkArea;
        private System.Windows.Forms.CheckBox chkHypotenuse;
        private System.Windows.Forms.CheckBox chkPerimeter;
    }
}

