﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TriangleDialog
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double sideA, sideB;
        double area;
        double hypotenuse;
        double perimeter;
        int accu = 3;

        private void buttonCalc_Click(object sender, EventArgs e)
        {
            sideA = Convert.ToDouble(textBoxA.Text);
            sideB = Convert.ToDouble(textBoxB.Text);
            accu = Convert.ToInt16(textBoxAccu.Text);

            labelArea.Text = " ";
            labelHypo.Text = "";
            labelPeri.Text = "";

            area = 0.5 * sideB * sideA;
            area = Math.Round(area, accu);

            double ASquare = sideA * sideA;
            double BSquare = Math.Pow(sideB, 2);
            hypotenuse = Math.Sqrt(ASquare + BSquare);
            hypotenuse = Math.Round(hypotenuse, accu);

            perimeter = sideA + sideB + hypotenuse;
            perimeter = Math.Round(perimeter, accu);

            if (chkArea.Checked == true)
            {
                labelArea.Text = "Area of Triangle is " + area;
            }

            if (chkHypotenuse.Checked == true)
            {
                labelHypo.Text = "Hypotenuse is " + hypotenuse;
            }

            if (chkPerimeter.Checked == true)
            {
                labelPeri.Text = "Perimeter is " + perimeter;
            }
        }
    }
}
